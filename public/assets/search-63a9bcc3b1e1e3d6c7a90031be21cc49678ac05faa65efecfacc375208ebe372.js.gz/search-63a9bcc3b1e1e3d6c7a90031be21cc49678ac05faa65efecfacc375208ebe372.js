$(document).ready(function(){

  $('.search').click(function(){
    $('#form-control-search').focus();
    return true;
  });

});
