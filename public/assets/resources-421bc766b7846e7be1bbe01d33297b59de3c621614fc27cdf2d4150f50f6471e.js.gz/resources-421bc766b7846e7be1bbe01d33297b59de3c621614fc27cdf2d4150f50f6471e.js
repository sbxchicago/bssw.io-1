$(document).ready(function(){

  $('.lightbox a').click(function(){
    return false;
  });

});
